# HSC3D

HSC3D: a Python package to quantify three-dimensional habitat structural complexity

## Installation

``pip install hsc3d`` to install the package or clone the code and install through ``pip intall -e .``

## Usage

See ``sample_usage.ipynb``
